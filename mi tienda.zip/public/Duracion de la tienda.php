<ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item">
        <a href="Home.php" class="nav-link active">  
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink: href="#"/></svg>
          Home
        </a>
      </li>
      <li>
        <a href="Duracion de la tienda.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:/></svg>
          Duracion de la tienda
        </a>
      </li>
      <li>
        <a href="Papeleria.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:/></svg>
          papeleria
        </a>
      </li>
      <li>
        <a href="Productos.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:/></svg>
          Productos
        </a>
      </li>
      <li>
        <a href="Perfil del negocio.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:/></svg>
          Perfil del negocio
        </a>
      </li>
    </ul>
