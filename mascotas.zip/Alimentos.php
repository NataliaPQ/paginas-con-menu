<ul class="nav flex-column">
            <li class="nav-item">
              <a href="Alimentos.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Alimentos
              </a>
              </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Arenas.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Arenas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Juguetes.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Juguetes
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Snacks.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                Snacks
              </a>
            </li>
    
              </a>
            </li>
          </ul>